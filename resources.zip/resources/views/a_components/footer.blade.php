<footer class="position-absolute bottom-0 w-100">
    {{-- make the x button using boostrap --}}
    <div class="d-flex justify-content-between ">
        <a href="/sign-out" class="btn btn-danger">Log Out</a>
        <p>Mudiyanto Setiawan / 090213101</p>
    </div>
</footer>