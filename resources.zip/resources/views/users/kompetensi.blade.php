<x-layout>
    <div>
        <div class="card p-5">
            <div class="card-body">
                <div>
                    <h1>Standar Kompetensi : </h1>
                    <ul>
                        <li>Memahami Hubungan Antara Mahluk Hidup Dengan Lingkugan tempat hidupnya</li>
                    </ul>
                </div>
                <hr>
                <div>
                    <h1>Kompetensi Dasar</h1>
                    <ul>
                        <li>1.1 Mendeskripsikan hubungan antara ciri-ciri khusus yang dimiliki hewan ( kelelawar, cicak, bebek ), dan linkungan hidupnya</li>
                        <li>1.2 Mendeskripsikan hubungan antara ciri-ciri khusus yang dimiliki tumbuhan ( kaktus, tumbuhan pemakan serangga ) dan lingkungan hidupnya</li>
                    </ul>
                </div>
            </div>
        
        </div>
        <a href="/" class="btn btn-primary mt-4">Kembali</a>
    </div>
   

</x-layout>