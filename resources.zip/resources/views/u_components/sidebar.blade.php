

 {{-- <div class="d-flex flex-column gap-1 w-100">
            <div><a href="/kompetensi" class="btn btn-warning w-100 text-center">Kompetensi</a></div>
            <div><a href="/materi1" class="btn btn-success w-100 text-center">Materi 1</a></div>
            <div><a href="" class="btn btn-success w-100 text-center">Materi 2</a></div>
            <div><a href="/evaluasi" class="btn btn-success w-100 text-center">Evaluasi</a></div>
            <div><a href="/petunjuk" class="btn btn-success w-100 text-center">Petunjuk</a></div>
            <div><a href="/laporan" class="btn btn-success w-100 text-center">Laporan</a></div>
            <div><a href="/sign-out" class="btn btn-danger w-100 text-center mt-5">Log Out</a></div>
</div> --}}
